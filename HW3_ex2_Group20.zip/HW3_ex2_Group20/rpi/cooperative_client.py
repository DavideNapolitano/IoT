from MyMQTT import MyMQTT
import time
import json
import base64
import datetime
import numpy as np
import pandas as pd
import tensorflow as tf
import tensorflow.lite as tflite
import subprocess
from SignalGenerator import SignalGenerator

def message_handler(topic, message):
    msg=json.loads(message)
    if topic=="/270005N/inference1":
        idx=0
    if topic=="/270005N/inference2":
        idx=1
    if topic=="/270005N/inference3":
        idx=2
    myCC.pred[idx].append(msg["probs"])
    if all(myCC.pred):
        somma=np.zeros(8, dtype=np.float64)
        for j in range(myCC.NumberInfClient):
            somma=somma+np.array(myCC.pred[j][0])
            myCC.pred[j].pop(0)
        best=np.argmax(somma)
        if myCC.labels[myCC.counter]==best:
            myCC.correct+=1
        myCC.counter+=1
    
# MESSAGE HANDLER se l' inference client invia vettore di probabilità + numero audio processato
# def message_handler(topic,message):
#     msg=json.loads(message)
#     msg_key=msg["number"]
#     if msg_key in myCC.datastructure.keys():
#         myCC.datastructure[msg["number"]].append(msg["probs"])
#         if len(myCC.datastructure[msg["number"]])==3:
#             somma=np.zeros(8, dtype=np.float64)
#             for j in range(myCC.NumberInfClient):
#                 somma=somma+np.array(myCC.datastructure[msg["number"]][j])
#             best=np.argmax(somma)
#             if myCC.labels[int(msg_key)]==best:
#                 myCC.correct+=1
#             myCC.counter+=1
#     else:
#         myCC.datastructure[msg["number"]]=[msg["probs"]]
        

start=datetime.datetime.now()
LABELS=["down","stop","right","left","up","yes","no","go"]
generator=SignalGenerator(LABELS,16000,640,320,40,20,4000,321,2) #2 indica sr=16000
test_d=pd.read_csv("kws_test_split.txt", header=None)
test_data=test_d.values.squeeze()
test_ds = generator.make_dataset(test_data, False)

clientID="rpi 1"
myCC = MyMQTT("rpi 1", "mqtt.eclipseprojects.io", 1883, message_handler, 3)
print("running %s" %(clientID))
myCC.start()
myCC.mySubscribe("/270005N/inference1")
myCC.mySubscribe("/270005N/inference2")
myCC.mySubscribe("/270005N/inference3")

for idx,el in enumerate(test_ds): 
    print(f"AUDIO NUMBER {idx}")
    np_mfccs=el[0].numpy() #solo gli mfccs, no metadata
    audio_b64=base64.b64encode(np_mfccs)
    audio_string=audio_b64.decode()
    true_lab=el[1].numpy()[0] 
    myCC.labels.append(true_lab)
    now=datetime.datetime.now()
    timestamp=int(now.timestamp())
    audio={
        "bn":"http://192.168.1.107/",
        "bt":timestamp,
        "e":[{"n":"audio", "u":"/", "t": 0, "vd": audio_string},
            ]
        }
    audio_json=json.dumps(audio)
    myCC.myPublish ("/270005N/rpi", audio_json)
    time.sleep(0.01) #0.001 con QOS=0
time.sleep(1) #SLEEP PER ASPETTARE EVENTUALI MESSAGGI NON ANCORA RICEVUTI

end=datetime.datetime.now()
# print(f"Correct Prediction: {myCC.correct}")
# print(f"Total audio arrived: {myCC.counter}")
print(f"Accuracy: {myCC.correct/myCC.counter*100}")
print(f"Execution time: {end-start}")
print("ending %s" %(clientID))
myCC.stop()
