from MyMQTT import MyMQTT
import time
import json
import tensorflow as tf
from tensorflow import keras
import tensorflow.lite as tflite
import argparse
import base64
import numpy as np

def message_handler(topic, message):
    input_json=json.loads(message)
    events=input_json["e"]
    mfccs_string=None
    for event in events:
        if event["n"]=="audio":
            mfccs_string=event["vd"]
            mfccs_string=base64.b64decode(mfccs_string)
    mfccs=np.frombuffer(mfccs_string, dtype=np.float32)
    mfccs=np.reshape(mfccs, (49,10))
    mfccs=tf.expand_dims(mfccs,-1)
    mfccs=tf.expand_dims(mfccs,0)
    myIC.interpreter.set_tensor(myIC.input_details[0]['index'], mfccs) #COPY DATA INTO THE BUFFER
    myIC.interpreter.invoke() #CALL THE INTERPRETER
    my_output = myIC.interpreter.get_tensor(myIC.output_details[0]['index']) #SAVE THE OUTPUT
    m_o=np.array(my_output.squeeze())
    probs=np.exp(m_o)/sum(np.exp(m_o))
    output_body={
        "probs": probs.tolist(),
        #"number": str(myIC.counter) #NUMERO AUDIO ELABORATO
        }
    output_json=json.dumps(output_body)
    myIC.myPublish(myIC.topic, output_json)
    myIC.counter+=1
        

parser = argparse.ArgumentParser()
parser.add_argument('--model', type=str, required=True, help='model path')
args = parser.parse_args()
if args.model=="./1.tflite":
    clientID="inference 1"
    myIC = MyMQTT(clientID, "mqtt.eclipseprojects.io", 1883, message_handler)
    myIC.topic="/270005N/inference1"
if args.model=="./2.tflite":
    clientID="inference 2"
    myIC = MyMQTT(clientID, "mqtt.eclipseprojects.io", 1883, message_handler)
    myIC.topic="/270005N/inference2"
if args.model=="./3.tflite":
    clientID="inference 3"
    myIC = MyMQTT(clientID, "mqtt.eclipseprojects.io", 1883, message_handler)
    myIC.topic="/270005N/inference3"
    
labels=["down","stop","right","left","up","yes","no","go"]
myIC.interpreter = tflite.Interpreter(model_path=args.model)
myIC.interpreter.allocate_tensors()
myIC.input_details = myIC.interpreter.get_input_details() #DICTIONARY
myIC.output_details = myIC.interpreter.get_output_details ()

myIC.start()
print ("running %s" % (clientID))
myIC.mySubscribe("/270005N/rpi")

while (myIC.counter<800):
    time.sleep(0.01)
    
print ("ending %s" % (clientID))
myIC.stop()
