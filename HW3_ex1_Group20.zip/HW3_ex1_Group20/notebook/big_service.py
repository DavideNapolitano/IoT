import json
import cherrypy
import base64
import tensorflow as tf
import tensorflow.lite as tflite
import numpy as np

class BigService(object):
    exposed=True
    
    def __init__(self):
        self.interpreter = tflite.Interpreter(model_path="./big.tflite")
        self.interpreter.allocate_tensors()
        self.input_details = self.interpreter.get_input_details() #DICTIONARY
        self.output_details = self.interpreter.get_output_details ()        
        self.linear_to_mel_weight_matrix=tf.signal.linear_to_mel_weight_matrix(40,321,16000,20,4000)
        self.labels=["down","stop","right","left","up","yes","no","go"]
        
    def preprocess(self, a_b):
        audio,_=tf.audio.decode_wav(a_b)
        audio=tf.squeeze(audio,axis=1)
        zero_padding=tf.zeros([16000] - tf.shape(audio), dtype=tf.float32)
        audio=tf.concat([audio,zero_padding],0)
        audio.set_shape([16000])
        stft=tf.signal.stft(audio,frame_length=640, frame_step=320, fft_length=640)
        spectrogram=tf.abs(stft)
        mel_spectrogram=tf.tensordot(spectrogram,self.linear_to_mel_weight_matrix,1)
        log_mel_spectrogram=tf.math.log(mel_spectrogram+1.e-6)
        mfccs=tf.signal.mfccs_from_log_mel_spectrograms(log_mel_spectrogram)
        mfccs=mfccs[...,:10]
        mfccs=tf.expand_dims(mfccs,-1)
        mfccs=tf.expand_dims(mfccs,0)
        return mfccs
        
    def GET(self, *path, **query):
        pass

    def PUT(self, *path, **query):
        input_body=cherrypy.request.body.read()
        input_body=json.loads(input_body)
        events=input_body["e"]
        audio_string=None
        for event in events:
            if event["n"]=="audio":
                audio_string=event["vd"]
                #print(audio_string)
        if audio_string is None:
            raise cherrypy.HTTPError(400,"no audio event")
        
        audio_bytes=base64.b64decode(audio_string)
        mfccs=self.preprocess(audio_bytes)
        my_input=mfccs
        self.interpreter.set_tensor(self.input_details[0]['index'], my_input) #COPY DATA INTO THE BUFFER
        self.interpreter.invoke() #CALL THE INTERPRETER
        my_output = self.interpreter.get_tensor(self.output_details[0]['index']) #SAVE THE OUTPUT

        output=np.argmax(my_output)
        label=self.labels[output]
        
        output_body={
            "label":label,
            }
        output_body=json.dumps(output_body)
        return output_body
        
    
    def POST(self, *path, **query):
        pass
        
    def DELETE(self, *path, **query):
        pass
    

if __name__ == '__main__':
    conf = {
        '/': {
            'request.dispatch': cherrypy.dispatch.MethodDispatcher(),
        }
    }
    cherrypy.tree.mount (BigService(),'',conf)
    cherrypy.config.update({'server.socket_host': '0.0.0.0'})
    cherrypy.config.update({'server.socket_port': 8080})
    cherrypy.engine.start()
    cherrypy.engine.block()