import base64
import datetime
import numpy as np
import json
import requests
import os
import pandas as pd
import tensorflow as tf
import tensorflow.lite as tflite
from SignalGenerator import SignalGenerator

LABELS=["down","stop","right","left","up","yes","no","go"]
generator=SignalGenerator(LABELS,16000,320,160,40,20,4000,161,1)
test_d=pd.read_csv("./kws_test_split.txt", header=None)
test_data=test_d.values.squeeze() #PATH TEST DATA
test_ds = generator.make_dataset(test_data, False)
print("DATASET GENERATED")

#INTERPRETER
interpreter = tflite.Interpreter(model_path="./little.tflite")
interpreter.allocate_tensors()
input_details = interpreter.get_input_details() #DICTIONARY
output_details = interpreter.get_output_details ()

counter=0
correct=0
sent=0
net_weight=0
for idx,el in enumerate(test_ds):
    counter+=1
    my_input=el[0].numpy()
    interpreter.set_tensor(input_details[0]['index'], my_input) #COPY DATA INTO THE BUFFER
    interpreter.invoke() #CALL THE INTERPRETER
    my_output = interpreter.get_tensor(output_details[0]['index']) #SAVE THE OUTPUT
    m_o=np.array(my_output.squeeze())
    probs=np.exp(m_o)/sum(np.exp(m_o))
    max_idx=np.argmax(probs)
    true_lab=el[1].numpy()[0]
    true_lab_string=LABELS[true_lab]
    sorted_output=np.sort(probs)
    now=datetime.datetime.now()
    timestamp=int(now.timestamp())
    SM=sorted_output[-1]-sorted_output[-2]
    if SM<0.60:
        print("Call Big Service...")
        sent+=1
        audio_binary = tf.io.read_file(test_data[idx])
        audio=audio_binary.numpy()
        audio_b64=base64.b64encode(audio)
        audio_string=audio_b64.decode()
        body={
            "bn": "http://192.168.1.107/",
            "bt": timestamp,
            "e":[{"n": "audio", "u": "/", "t": 0, "vd": audio_string},
                ]
            }
        weight=json.dumps(body)
        net_weight+=len(weight)
        
        url="http://192.168.1.132:8080"
        r=requests.put(url, json=body)

        if r.status_code==200:
            rbody=r.json()
            label=rbody["label"]
            if label==true_lab_string:
                correct+=1
        else:
            print("Error")
            print(r.text)
    else:
       if true_lab==max_idx:
           correct+=1

print(f"Accuracy: {correct/counter*100}%")
print(f"Network Weight: {net_weight/1048576} MB")
print(f"Number audio sent: {sent}")











